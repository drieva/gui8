﻿namespace FineForOverdueBooks
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.booksCheckedOutLabel = new System.Windows.Forms.Label();
            this.booksCheckedOutTextBox = new System.Windows.Forms.TextBox();
            this.daysOverdueLabel = new System.Windows.Forms.Label();
            this.daysOverdueTextBox = new System.Windows.Forms.TextBox();
            this.calculateButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // booksCheckedOutLabel
            // 
            this.booksCheckedOutLabel.AutoSize = true;
            this.booksCheckedOutLabel.Location = new System.Drawing.Point(12, 15);
            this.booksCheckedOutLabel.Name = "booksCheckedOutLabel";
            this.booksCheckedOutLabel.Size = new System.Drawing.Size(117, 13);
            this.booksCheckedOutLabel.TabIndex = 0;
            this.booksCheckedOutLabel.Text = "Number of books out:";
            // 
            // booksCheckedOutTextBox
            // 
            this.booksCheckedOutTextBox.Location = new System.Drawing.Point(135, 12);
            this.booksCheckedOutTextBox.Name = "booksCheckedOutTextBox";
            this.booksCheckedOutTextBox.Size = new System.Drawing.Size(100, 20);
            this.booksCheckedOutTextBox.TabIndex = 1;
            // 
            // daysOverdueLabel
            // 
            this.daysOverdueLabel.AutoSize = true;
            this.daysOverdueLabel.Location = new System.Drawing.Point(12, 41);
            this.daysOverdueLabel.Name = "daysOverdueLabel";
            this.daysOverdueLabel.Size = new System.Drawing.Size(80, 13);
            this.daysOverdueLabel.TabIndex = 2;
            this.daysOverdueLabel.Text = "Days overdue:";
            // 
            // daysOverdueTextBox
            // 
            this.daysOverdueTextBox.Location = new System.Drawing.Point(135, 38);
            this.daysOverdueTextBox.Name = "daysOverdueTextBox";
            this.daysOverdueTextBox.Size = new System.Drawing.Size(100, 20);
            this.daysOverdueTextBox.TabIndex = 3;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(78, 76);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 4;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(247, 111);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.daysOverdueTextBox);
            this.Controls.Add(this.daysOverdueLabel);
            this.Controls.Add(this.booksCheckedOutTextBox);
            this.Controls.Add(this.booksCheckedOutLabel);
            this.Name = "Form1";
            this.Text = "Fine For Overdue Books";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label booksCheckedOutLabel;
        private System.Windows.Forms.TextBox booksCheckedOutTextBox;
        private System.Windows.Forms.Label daysOverdueLabel;
        private System.Windows.Forms.TextBox daysOverdueTextBox;
        private System.Windows.Forms.Button calculateButton;
    }
}
