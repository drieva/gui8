using System;
using System.Windows.Forms;

namespace FineForOverdueBooks
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            int numBooksCheckedOut = Convert.ToInt32(booksCheckedOutTextBox.Text);
            int numDaysOverdue = Convert.ToInt32(daysOverdueTextBox.Text);

            decimal fine = CalculateFine(numBooksCheckedOut, numDaysOverdue);

            MessageBox.Show($"The fine for overdue books is ${fine.ToString("0.00")}");
        }

        private decimal CalculateFine(int numBooksCheckedOut, int numDaysOverdue)
        {
            decimal fine = 0;

            if (numDaysOverdue <= 7)
            {
                fine = numBooksCheckedOut * 0.10m * numDaysOverdue;
            }
            else
            {
                fine = numBooksCheckedOut * 0.10m * 7 + numBooksCheckedOut * 0.20m * (numDaysOverdue - 7);
            }

            return fine;
        }
    }
}
